cd('D:\Schraege_Gas_Challenge_Data');
dirA = '';
dirB = '';
tic;

%% Read PCVIPR data
% Baseline
cd(dirA)
disp(pwd);
loadPCVIPR
base.CD = CD; %complex difference
base.MAG = MAG; %magnitude
base.VMEAN = VMEAN; %mean velocity
base.header = pcviprHeader; %load metadata
clear cd CD mag MAG pcviprH* v VMEAN directory
save base.mat base

% Indomethacin (hypoxia)
cd(dirB)
disp(pwd);
loadPCVIPR
indo.CD = CD;
indo.MAG = MAG;
indo.VMEAN = VMEAN;
indo.header = pcviprHeader;
clear cd CD mag MAG pcviprH* VMEAN directory
save indo.mat indo

toc
%% Affine Registration
temp_base = rescale(base.CD + base.MAG); %increase magnitude weighting
temp_move = rescale(indo.CD + indo.MAG);
fixed = zeros(size(temp_base));
moving = zeros(size(temp_move));
fixed(:,:,90:268) = temp_base(:,:,90:268);
moving(:,:,48:235) = temp_move(:,:,48:235);
%fixed = rescale(base.MAG);
%moving = rescale(indo.MAG);
%fixed = int16(rescale(base.CD)>0.20);
%moving = int16(rescale(indo.CD)>0.20);

figure; imshowpair(fixed(:,:,80), moving(:,:,80)); title('Unregistered Axial Slices');
%saveas(gcf,'Unregistered_Low.png'); close gcf
figure; imshowpair(fixed(:,:,130), moving(:,:,130)); title('Unregistered Axial Slices');
%saveas(gcf,'Unregistered_Mid.png'); close gcf
figure; imshowpair(fixed(:,:,180), moving(:,:,180)); title('Unregistered Axial Slices');
%saveas(gcf,'Unregistered_High.png'); close gcf

[optimizer,metric] = imregconfig('monomodal');
optimizer.MaximumIterations = 200;
%optimizer.RelaxationFactor = 0.6;
%optimizer.MinimumStepLength = 1e-06;
%optimizer.GradientMagnitudeTolerance = 1e-04;
metric = registration.metric.MattesMutualInformation;
Rbase = imref3d(size(fixed),base.header.fovx/base.header.matrixx, ...
    base.header.fovy/base.header.matrixy, base.header.fovz/base.header.matrixz);
Rindo = imref3d(size(moving),indo.header.fovx/indo.header.matrixx, ...
    indo.header.fovy/indo.header.matrixy, indo.header.fovz/indo.header.matrixz);
%shift = affine3d([1 0 0 0; 0 1 0 0; 0 0 1 0; -4 2 26 1]);
% disp('STARTING INITIAL RIGID REGISTRATION');
% geomtformInit = imregtform(moving,Rindo,fixed,Rbase,'rigid', ...
%    optimizer,metric,'DisplayOptimization',true,'InitialTransformation',shift);
% toc
disp('STARTING AFFINE REGISTRATION');
geomtform = imregtform(moving,Rindo,fixed,Rbase,'affine', ...
    optimizer,metric,'DisplayOptimization',true,'InitialTransformation',geomtformInit);
toc

MAGt = imwarp(indo.MAG,Rindo,geomtform,'bicubic','OutputView',Rbase);
CDt = imwarp(indo.CD,Rindo,geomtform,'bicubic','OutputView',Rbase);
figure; imshowpair(MAGt(:,:,80),base.MAG(:,:,80));
figure; imshowpair(MAGt(:,:,130),base.MAG(:,:,130));
figure; imshowpair(MAGt(:,:,180),base.MAG(:,:,180));

figure; imshowpair(CDt(:,:,80),base.CD(:,:,80));
figure; imshowpair(CDt(:,:,130),base.CD(:,:,130));
figure; imshowpair(CDt(:,:,180),base.CD(:,:,180));

%indoT.MAG = imwarp(indo.MAG,Rindo,geomtform,'bicubic','OutputView',Rbase);
%indoT.CD = imwarp(indo.CD,Rindo,geomtform,'bicubic','OutputView',Rbase);
%figure; imshowpair(indoT.MAG(:,:,80),base.MAG(:,:,80));
%saveas(gcf,'MAG_Low.png'); close gcf
%figure; imshowpair(indoT.MAG(:,:,130),base.MAG(:,:,130));
%saveas(gcf,'MAG_Mid.png'); close gcf
%figure; imshowpair(indoT.MAG(:,:,180),base.MAG(:,:,180));
%saveas(gcf,'MAG_High.png'); close gcf

%figure; imshowpair(indoT.CD(:,:,80),base.CD(:,:,80));
%saveas(gcf,'CD_Low.png'); close gcf
%figure; imshowpair(indoT.CD(:,:,130),base.CD(:,:,130));
%saveas(gcf,'CD_Mid.png'); close gcf
%figure; imshowpair(indoT.CD(:,:,180),base.CD(:,:,180));
%saveas(gcf,'CD_High.png'); close gcf

%% Deformable Registration
disp('STARTING DEFORMABLE REGISTRATION');
[deftform,MAGt2] = imregdemons((MAGt+CDt),(base.MAG+base.CD),[100 100 50],'AccumulatedFieldSmoothing',1.3);
toc

%temp = imwarp(indo.MAG,Rindo,geomtform,'bicubic','OutputView',Rbase);
indoT.MAG = imwarp(MAGt,deftform,'SmoothEdges',true);
%temp = imwarp(indo.CD,Rindo,geomtform,'bicubic','OutputView',Rbase);
indoT.CD = imwarp(CDt,deftform,'SmoothEdges',true);

figure; imshowpair(indoT.MAG(:,:,80),base.MAG(:,:,80));
figure; imshowpair(indoT.MAG(:,:,130),base.MAG(:,:,130));
figure; imshowpair(indoT.MAG(:,:,180),base.MAG(:,:,180));

figure; imshowpair(indoT.CD(:,:,80),base.CD(:,:,80));
figure; imshowpair(indoT.CD(:,:,130),base.CD(:,:,130));
figure; imshowpair(indoT.CD(:,:,180),base.CD(:,:,180));

%% Save files
disp('TRANSFERRING FILES');
dirC = [dirB filesep 'dat_registered'];
mkdir(dirC);
cd(dirC);
save geomtform.mat geomtform
save optimizer.mat optimizer
save metric.mat metric
save Rbase.mat Rbase
save Rindo.mat Rindo
if exist('deftform','var')
    save deftform.mat deftform
end 

% filename = 'CD.dat';
% fid = fopen(filename,'w');
% fwrite(fid,indoT.CD,'int16');
% fclose(fid);

filename = 'MAG.dat';
fid = fopen(filename,'w');
fwrite(fid,indoT.MAG,'int16');
fclose(fid);

if exist('deftform','var')
    temp = imwarp(indo.VMEAN(:,:,:,1),Rindo,geomtform,'bicubic','OutputView',Rbase);
    indoT.VMEAN(:,:,:,1) = imwarp(temp,deftform,'SmoothEdges',true);
else
    indoT.VMEAN(:,:,:,1) = imwarp(indo.VMEAN(:,:,:,1),Rindo,geomtform,'bicubic','OutputView',Rbase);
end 
filename = 'comp_vd_1.dat';
fid = fopen(filename,'w');
fwrite(fid,indoT.VMEAN(:,:,:,1),'int16');
fclose(fid);

if exist('deftform','var')
    temp = imwarp(indo.VMEAN(:,:,:,2),Rindo,geomtform,'bicubic','OutputView',Rbase);
    indoT.VMEAN(:,:,:,2) = imwarp(temp,deftform,'SmoothEdges',true);
else
    indoT.VMEAN(:,:,:,2) = imwarp(indo.VMEAN(:,:,:,2),Rindo,geomtform,'bicubic','OutputView',Rbase);
end 
filename = 'comp_vd_2.dat';
fid = fopen(filename,'w');
fwrite(fid,indoT.VMEAN(:,:,:,2),'int16');
fclose(fid);

if exist('deftform','var')
    temp = imwarp(indo.VMEAN(:,:,:,3),Rindo,geomtform,'bicubic','OutputView',Rbase);
    indoT.VMEAN(:,:,:,3) = imwarp(temp,deftform,'SmoothEdges',true);
else
    indoT.VMEAN(:,:,:,3) = imwarp(indo.VMEAN(:,:,:,3),Rindo,geomtform,'bicubic','OutputView',Rbase);
end 
filename = 'comp_vd_3.dat';
fid = fopen(filename,'w');
fwrite(fid,indoT.VMEAN(:,:,:,3),'int16');
fclose(fid);

for vd = 1:3
    for f = 1:base.header.frames
        temp = v(:,:,:,vd,f);
        temp = imwarp(temp,Rindo,geomtform,'bicubic','OutputView',Rbase);
        if exist('deftform','var')
            temp = imwarp(temp,deftform,'SmoothEdges',true);
        end 
        frame = sprintf('%03d', f-1);
        dim = num2str(vd);
        filename = ['ph_' frame '_vd_' dim '.dat'];
        fid = fopen(filename,'w');
        fwrite(fid,temp,'int16');
        fclose(fid);
    end 
end 

copyfile([dirA filesep 'CD.dat'],pwd);
copyfile([dirA filesep 'ph_*_cd.dat'],pwd);
copyfile([dirA filesep 'ph_*_mag.dat'],pwd);
copyfile([dirA filesep 'pcvipr_header.txt'],pwd);

toc

email_address = '';
setpref('Internet','E_mail',email_address);
setpref('Internet','SMTP_Server','smtp.wiscmail.wisc.edu');
sendmail('gsroberts@wisc.edu','Hello From MATLAB!','DONE WITH SCRIPT!');
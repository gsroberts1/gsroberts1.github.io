function PCA = makePCA(MAG,CD,w,p)

PCA = abs( (w.*MAG).^p + ((1-w).*CD).^p ).^(1/p);

end


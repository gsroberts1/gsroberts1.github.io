directory = pwd;
fid = fopen([directory '\pcvipr_header.txt'], 'r');
dataArray = textscan(fid, '%s%s%[^\n\r]', 'Delimiter', ' ', 'MultipleDelimsAsOne', true, 'ReturnOnError', false);
fclose(fid); 

dataArray{1,2} = cellfun(@str2num,dataArray{1,2}(:), 'UniformOutput', false);
pcviprHeader = cell2struct(dataArray{1,2}(:), dataArray{1,1}(:), 1);
resx = pcviprHeader.matrixx;      
resy = pcviprHeader.matrixy;
resz = pcviprHeader.matrixz;
nframes = pcviprHeader.frames;           

MAG = load_dat(fullfile(directory,'MAG.dat'),[resx resy resz]);
CD = load_dat(fullfile(directory,'CD.dat'),[resx resy resz]);
VMEAN = zeros(resx,resy,resz,3);
for n = 1:3
    VMEAN(:,:,:,n) = load_dat(fullfile(directory,['comp_vd_' num2str(n) '.dat']),[resx resy resz]);
end

v = zeros(resx,resy,resz,3,nframes);
mag = zeros(resx,resy,resz,nframes);
cd = zeros(resx,resy,resz,nframes);
for j = 1:nframes   
    v(:,:,:,1,j) = load_dat(fullfile(directory, ['\ph_' num2str(j-1,'%03i') '_vd_1.dat']),[resx resy resz]);
    v(:,:,:,2,j) = load_dat(fullfile(directory, ['\ph_' num2str(j-1,'%03i') '_vd_2.dat']),[resx resy resz]);
    v(:,:,:,3,j) = load_dat(fullfile(directory, ['\ph_' num2str(j-1,'%03i') '_vd_3.dat']),[resx resy resz]);
    mag(:,:,:,j) = load_dat(fullfile(directory, ['\ph_' num2str(j-1,'%03i') '_mag.dat']),[resx resy resz]);
    cd(:,:,:,j)  = load_dat(fullfile(directory, ['\ph_' num2str(j-1,'%03i') '_cd.dat']),[resx resy resz]);
end 
clear ans; clear j; clear nframes; clear res; clear n; clear fid; clear dataArray;

function v = load_dat(name, res)
%% Load Dat
% Loads in dat files in current directory.
[fid,errmsg]= fopen(name,'r');
if fid < 0  % If name does not exist in directory
    disp(['Error Opening Data : ',errmsg]);
end

% Reads in as short, reshapes by image res.
v = reshape(fread(fid,'short=>single'),res);
fclose(fid);
end 
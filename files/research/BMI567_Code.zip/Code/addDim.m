imList = dir('PIL*'); %get all strain folders
for im=1:length(imList) %for every strain folder

end 